// app.js
const express      = require('express');
const cors         = require('cors');
const errorHandler = require('./src/middlewares/errorHandler');
require('dotenv').config();

// Import des routes
const authRoutes    = require('./src/routes/authRoutes');
const clientRoutes  = require('./src/routes/clientRoutes');
const livreurRoutes = require('./src/routes/livreurRoutes');
const adminRoutes   = require('./src/routes/adminRoutes');

const app = express();

// ── Middlewares globaux ────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// ── Routes ────────────────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api',          clientRoutes);   // /api/categories, /api/produits, /api/commandes
app.use('/api/livreur',  livreurRoutes);
app.use('/api/admin',    adminRoutes);

// ── Route de santé ────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({ success: true, message: '🍔 BurgerTime API is running!' });
});

// ── Gestion des routes inexistantes ───────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route introuvable.' });
});

// ── Gestionnaire d'erreurs global (doit être en dernier) ──────────────────
app.use(errorHandler);

module.exports = app;
