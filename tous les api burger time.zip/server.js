// server.js
const app  = require('./app');
const http = require('http');
require('dotenv').config();

const PORT   = process.env.PORT || 3000;
const server = http.createServer(app);

server.listen(PORT, () => {
  console.log(`🍔 BurgerTime API démarrée sur http://localhost:${PORT}`);
});
