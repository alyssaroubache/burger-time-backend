// src/controllers/clientController.js
const pool = require('../config/db');

// ─────────────────────────────────────────────
// GET /api/categories
// ─────────────────────────────────────────────
const getCategories = async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, nom, description, url_image, ordre_affichage
       FROM categories
       WHERE actif = true
       ORDER BY ordre_affichage ASC`
    );
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────
// GET /api/produits?categorieId=X
// ─────────────────────────────────────────────
const getProduits = async (req, res, next) => {
  const { categorieId } = req.query;

  try {
    let query  = `SELECT p.id, p.nom, p.description, p.prix, p.url_image,
                         p.temps_preparation, c.nom AS categorie
                  FROM produits p
                  JOIN categories c ON p.categorie_id = c.id
                  WHERE p.disponible = true`;
    const params = [];

    if (categorieId) {
      params.push(categorieId);
      query += ` AND p.categorie_id = $${params.length}`;
    }

    query += ` ORDER BY p.nom ASC`;

    const result = await pool.query(query, params);
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────
// GET /api/produits/:id
// ─────────────────────────────────────────────
const getProduitById = async (req, res, next) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT p.id, p.nom, p.description, p.prix, p.url_image,
              p.temps_preparation, c.nom AS categorie
       FROM produits p
       JOIN categories c ON p.categorie_id = c.id
       WHERE p.id = $1 AND p.disponible = true`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Produit introuvable.' });
    }

    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────
// POST /api/commandes
// ─────────────────────────────────────────────
const createCommande = async (req, res, next) => {
  const {
    client_prenom,
    client_nom,
    client_telephone,
    client_email,
    adresse_livraison,
    livraison_lat,
    livraison_lng,
    instructions_livraison,
    heure_prevue,
    produits, // [{ produit_id, quantite, instructions_speciales }]
  } = req.body;

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // 1. Vérifier que tous les produits existent et sont disponibles
    const ids = produits.map((p) => p.produit_id);
    const produitsResult = await client.query(
      `SELECT id, prix FROM produits WHERE id = ANY($1) AND disponible = true`,
      [ids]
    );

    if (produitsResult.rows.length !== ids.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: 'Un ou plusieurs produits sont indisponibles ou introuvables.',
      });
    }

    // 2. Calculer le montant total
    const prixMap = {};
    produitsResult.rows.forEach((p) => { prixMap[p.id] = parseFloat(p.prix); });

    let montantTotal = 0;
    produits.forEach((p) => { montantTotal += prixMap[p.produit_id] * p.quantite; });

    // 3. Insérer la commande
    const commandeResult = await client.query(
      `INSERT INTO commandes
         (client_prenom, client_nom, client_telephone, client_email,
          adresse_livraison, livraison_lat, livraison_lng,
          instructions_livraison, heure_prevue, montant_total)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING id`,
      [
        client_prenom, client_nom, client_telephone, client_email || null,
        adresse_livraison, livraison_lat || null, livraison_lng || null,
        instructions_livraison || null, heure_prevue, montantTotal,
      ]
    );

    const commandeId = commandeResult.rows[0].id;

    // 4. Insérer les détails de la commande
    for (const p of produits) {
      const prixUnitaire = prixMap[p.produit_id];
      const sousTotal    = prixUnitaire * p.quantite;

      await client.query(
        `INSERT INTO details_commandes
           (commande_id, produit_id, quantite, prix_unitaire, sous_total, instructions_speciales)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [commandeId, p.produit_id, p.quantite, prixUnitaire, sousTotal, p.instructions_speciales || null]
      );
    }

    // 5. Enregistrer le statut initial dans l'historique
    await client.query(
      `INSERT INTO historique_statuts (commande_id, statut, notes)
       VALUES ($1, 'nouvelle', 'Commande créée par le client')`,
      [commandeId]
    );

    await client.query('COMMIT');

    res.status(201).json({
      success: true,
      message: 'Commande créée avec succès.',
      data: { id: commandeId, montant_total: montantTotal },
    });

  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

// ─────────────────────────────────────────────
// GET /api/commandes/:id
// ─────────────────────────────────────────────
const getCommandeById = async (req, res, next) => {
  const { id } = req.params;

  try {
    const commandeResult = await pool.query(
      `SELECT id, client_prenom, client_nom, adresse_livraison,
              heure_prevue, montant_total, statut, cree_le
       FROM commandes WHERE id = $1`,
      [id]
    );

    if (commandeResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Commande introuvable.' });
    }

    const detailsResult = await pool.query(
      `SELECT dc.quantite, dc.prix_unitaire, dc.sous_total,
              dc.instructions_speciales, p.nom AS produit
       FROM details_commandes dc
       JOIN produits p ON dc.produit_id = p.id
       WHERE dc.commande_id = $1`,
      [id]
    );

    res.status(200).json({
      success: true,
      data: {
        ...commandeResult.rows[0],
        produits: detailsResult.rows,
      },
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getCategories,
  getProduits,
  getProduitById,
  createCommande,
  getCommandeById,
};
