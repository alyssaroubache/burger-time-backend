// src/middlewares/validation.js

/**
 * Valide les champs obligatoires du body de la requête.
 * @param {string[]} fields - Liste des champs requis
 * @returns Middleware Express
 */
const requireFields = (fields) => (req, res, next) => {
  const missing = fields.filter((f) => {
    const val = req.body[f];
    return val === undefined || val === null || val === '';
  });

  if (missing.length > 0) {
    return res.status(400).json({
      success: false,
      message: `Champs obligatoires manquants : ${missing.join(', ')}`,
    });
  }

  next();
};

module.exports = { requireFields };
