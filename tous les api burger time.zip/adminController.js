// src/controllers/adminController.js
const pool   = require('../config/db');
const bcrypt = require('bcrypt');

// ─────────────────────────────────────────────
// GET /api/admin/tableau-de-bord
// ─────────────────────────────────────────────
const getTableauDeBord = async (req, res, next) => {
  try {
    const [commandes, ca, parStatut] = await Promise.all([
      pool.query(`SELECT COUNT(*) FROM commandes WHERE DATE(cree_le) = CURRENT_DATE`),
      pool.query(`SELECT COALESCE(SUM(montant_total), 0) AS total FROM commandes WHERE DATE(cree_le) = CURRENT_DATE AND statut != 'annulee'`),
      pool.query(`SELECT statut, COUNT(*) AS total FROM commandes WHERE DATE(cree_le) = CURRENT_DATE GROUP BY statut`),
    ]);

    res.status(200).json({
      success: true,
      data: {
        commandes_du_jour:   parseInt(commandes.rows[0].count),
        chiffre_affaires:    parseFloat(ca.rows[0].total),
        repartition_statuts: parStatut.rows,
      },
    });
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────
// PRODUITS
// ─────────────────────────────────────────────
const getProduits = async (req, res, next) => {
  const { search, page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;
  const params = [];
  let where    = '';

  if (search) {
    params.push(`%${search}%`);
    where = `WHERE p.nom ILIKE $${params.length}`;
  }

  try {
    const result = await pool.query(
      `SELECT p.id, p.nom, p.description, p.prix, p.disponible,
              p.temps_preparation, p.url_image, c.nom AS categorie
       FROM produits p
       JOIN categories c ON p.categorie_id = c.id
       ${where}
       ORDER BY p.nom ASC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, limit, offset]
    );
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) {
    next(err);
  }
};

const createProduit = async (req, res, next) => {
  const { nom, description, prix, categorie_id, url_image, temps_preparation } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO produits (nom, description, prix, categorie_id, url_image, temps_preparation)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [nom, description || null, prix, categorie_id, url_image || null, temps_preparation || null]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

const updateProduit = async (req, res, next) => {
  const { id } = req.params;
  const { nom, description, prix, categorie_id, url_image, temps_preparation } = req.body;
  try {
    const result = await pool.query(
      `UPDATE produits
       SET nom=$1, description=$2, prix=$3, categorie_id=$4,
           url_image=$5, temps_preparation=$6, maj_le=NOW()
       WHERE id=$7 RETURNING *`,
      [nom, description, prix, categorie_id, url_image, temps_preparation, id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Produit introuvable.' });
    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

const deleteProduit = async (req, res, next) => {
  const { id } = req.params;
  try {
    const result = await pool.query(`DELETE FROM produits WHERE id=$1 RETURNING id`, [id]);
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Produit introuvable.' });
    res.status(200).json({ success: true, message: 'Produit supprimé.' });
  } catch (err) {
    next(err);
  }
};

const toggleProduitDisponible = async (req, res, next) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `UPDATE produits SET disponible = NOT disponible, maj_le = NOW()
       WHERE id=$1 RETURNING id, disponible`,
      [id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Produit introuvable.' });
    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────
// CATÉGORIES
// ─────────────────────────────────────────────
const getCategories = async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT * FROM categories ORDER BY ordre_affichage ASC`
    );
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) { next(err); }
};

const createCategorie = async (req, res, next) => {
  const { nom, description, ordre_affichage, url_image } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO categories (nom, description, ordre_affichage, url_image)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [nom, description || null, ordre_affichage || 0, url_image || null]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) { next(err); }
};

const updateCategorie = async (req, res, next) => {
  const { id } = req.params;
  const { nom, description, ordre_affichage, url_image, actif } = req.body;
  try {
    const result = await pool.query(
      `UPDATE categories SET nom=$1, description=$2, ordre_affichage=$3,
       url_image=$4, actif=$5, maj_le=NOW() WHERE id=$6 RETURNING *`,
      [nom, description, ordre_affichage, url_image, actif, id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Catégorie introuvable.' });
    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (err) { next(err); }
};

const deleteCategorie = async (req, res, next) => {
  const { id } = req.params;
  try {
    const result = await pool.query(`DELETE FROM categories WHERE id=$1 RETURNING id`, [id]);
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Catégorie introuvable.' });
    res.status(200).json({ success: true, message: 'Catégorie supprimée.' });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────
// COMMANDES
// ─────────────────────────────────────────────
const getCommandes = async (req, res, next) => {
  const { statut, date } = req.query;
  const params = [];
  const conditions = [];

  if (statut) { params.push(statut); conditions.push(`statut = $${params.length}`); }
  if (date)   { params.push(date);   conditions.push(`DATE(cree_le) = $${params.length}`); }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const result = await pool.query(
      `SELECT id, client_prenom, client_nom, client_telephone,
              adresse_livraison, heure_prevue, montant_total, statut, cree_le
       FROM commandes ${where} ORDER BY cree_le DESC`,
      params
    );
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) { next(err); }
};

const getCommandeById = async (req, res, next) => {
  const { id } = req.params;
  try {
    const commande = await pool.query(`SELECT * FROM commandes WHERE id=$1`, [id]);
    if (commande.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Commande introuvable.' });

    const details = await pool.query(
      `SELECT dc.*, p.nom AS produit FROM details_commandes dc
       JOIN produits p ON dc.produit_id = p.id WHERE dc.commande_id=$1`, [id]
    );
    const historique = await pool.query(
      `SELECT hs.statut, hs.modifie_le, u.nom_complet AS modifie_par
       FROM historique_statuts hs
       LEFT JOIN utilisateurs u ON hs.modifie_par = u.id
       WHERE hs.commande_id=$1 ORDER BY hs.modifie_le ASC`, [id]
    );

    res.status(200).json({
      success: true,
      data: { ...commande.rows[0], produits: details.rows, historique: historique.rows },
    });
  } catch (err) { next(err); }
};

const updateStatutCommande = async (req, res, next) => {
  const { id }     = req.params;
  const { statut } = req.body;
  const adminId    = req.user.id;

  const STATUTS = ['nouvelle', 'prise', 'en_cours', 'livree', 'annulee'];
  if (!STATUTS.includes(statut))
    return res.status(400).json({ success: false, message: 'Statut invalide.' });

  try {
    const result = await pool.query(
      `UPDATE commandes SET statut=$1, maj_le=NOW() WHERE id=$2 RETURNING id`,
      [statut, id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Commande introuvable.' });

    await pool.query(
      `INSERT INTO historique_statuts (commande_id, statut, modifie_par, notes)
       VALUES ($1,$2,$3,'Modifié manuellement par l\'admin')`,
      [id, statut, adminId]
    );

    res.status(200).json({ success: true, message: `Statut mis à jour : ${statut}` });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────
// UTILISATEURS
// ─────────────────────────────────────────────
const getUtilisateurs = async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, nom_complet, email, telephone, role, actif, derniere_connexion, cree_le
       FROM utilisateurs ORDER BY cree_le DESC`
    );
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) { next(err); }
};

const createUtilisateur = async (req, res, next) => {
  const { email, nom_complet, telephone, role, mot_de_passe } = req.body;

  if (!['admin', 'livreur'].includes(role))
    return res.status(400).json({ success: false, message: 'Rôle invalide. (admin ou livreur)' });

  try {
    const motDePasseHash = await bcrypt.hash(mot_de_passe || 'BurgerTime2026!', 12);

    const result = await pool.query(
      `INSERT INTO utilisateurs (email, nom_complet, telephone, role, mot_de_passe_hash)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id, email, nom_complet, role`,
      [email, nom_complet, telephone || null, role, motDePasseHash]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    if (err.code === '23505')
      return res.status(409).json({ success: false, message: 'Cet email est déjà utilisé.' });
    next(err);
  }
};

const toggleUtilisateurActif = async (req, res, next) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `UPDATE utilisateurs SET actif = NOT actif, maj_le = NOW()
       WHERE id=$1 RETURNING id, actif`,
      [id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ success: false, message: 'Utilisateur introuvable.' });
    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (err) { next(err); }
};

module.exports = {
  getTableauDeBord,
  getProduits, createProduit, updateProduit, deleteProduit, toggleProduitDisponible,
  getCategories, createCategorie, updateCategorie, deleteCategorie,
  getCommandes, getCommandeById, updateStatutCommande,
  getUtilisateurs, createUtilisateur, toggleUtilisateurActif,
};
