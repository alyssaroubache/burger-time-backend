// src/routes/livreurRoutes.js
const express    = require('express');
const router     = express.Router();
const {
  getCommandesDisponibles,
  prendreCommande,
  changerStatut,
} = require('../controllers/livreurController');
const { protect, isLivreur } = require('../middlewares/auth');
const { requireFields }      = require('../middlewares/validation');

// Toutes les routes livreur nécessitent une authentification
router.use(protect, isLivreur);

/**
 * GET /api/livreur/commandes
 * Liste des commandes disponibles (statut = 'nouvelle')
 */
router.get('/commandes', getCommandesDisponibles);

/**
 * PUT /api/livreur/commandes/:id/prendre
 * Le livreur prend en charge une commande
 */
router.put('/commandes/:id/prendre', prendreCommande);

/**
 * PUT /api/livreur/commandes/:id/statut
 * Le livreur met à jour le statut d'une commande
 */
router.put(
  '/commandes/:id/statut',
  requireFields(['statut']),
  changerStatut
);

module.exports = router;
