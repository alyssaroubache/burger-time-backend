// src/routes/adminRoutes.js
const express  = require('express');
const router   = express.Router();
const {
  getTableauDeBord,
  getProduits,
  createProduit,
  updateProduit,
  deleteProduit,
  toggleProduitDisponible,
  getCategories,
  createCategorie,
  updateCategorie,
  deleteCategorie,
  getCommandes,
  getCommandeById,
  updateStatutCommande,
  getUtilisateurs,
  createUtilisateur,
  toggleUtilisateurActif,
} = require('../controllers/adminController');
const { protect, isAdmin } = require('../middlewares/auth');
const { requireFields }    = require('../middlewares/validation');

// Toutes les routes admin nécessitent une authentification admin
router.use(protect, isAdmin);

// --- Tableau de bord ---
router.get('/tableau-de-bord', getTableauDeBord);

// --- Produits ---
router.get('/produits',                        getProduits);
router.post('/produits',  requireFields(['nom', 'prix', 'categorie_id']), createProduit);
router.put('/produits/:id',                    updateProduit);
router.delete('/produits/:id',                 deleteProduit);
router.patch('/produits/:id/disponibilite',    toggleProduitDisponible);

// --- Catégories ---
router.get('/categories',                      getCategories);
router.post('/categories', requireFields(['nom']), createCategorie);
router.put('/categories/:id',                  updateCategorie);
router.delete('/categories/:id',               deleteCategorie);

// --- Commandes ---
router.get('/commandes',                       getCommandes);
router.get('/commandes/:id',                   getCommandeById);
router.put('/commandes/:id/statut', requireFields(['statut']), updateStatutCommande);

// --- Utilisateurs ---
router.get('/utilisateurs',                    getUtilisateurs);
router.post('/utilisateurs', requireFields(['email', 'nom_complet', 'role']), createUtilisateur);
router.patch('/utilisateurs/:id/actif',        toggleUtilisateurActif);

module.exports = router;
