// src/controllers/livreurController.js
const pool = require('../config/db');

// Ordre valide des statuts
const STATUTS_VALIDES  = ['nouvelle', 'prise', 'en_cours', 'livree', 'annulee'];
const TRANSITIONS      = {
  nouvelle: ['prise', 'annulee'],
  prise:    ['en_cours', 'annulee'],
  en_cours: ['livree'],
};

// ─────────────────────────────────────────────
// GET /api/livreur/commandes
// Commandes disponibles (statut = 'nouvelle')
// ─────────────────────────────────────────────
const getCommandesDisponibles = async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, client_prenom, client_nom, client_telephone,
              adresse_livraison, livraison_lat, livraison_lng,
              heure_prevue, montant_total, cree_le
       FROM commandes
       WHERE statut = 'nouvelle'
       ORDER BY heure_prevue ASC`
    );
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────
// PUT /api/livreur/commandes/:id/prendre
// Le livreur prend en charge une commande
// ─────────────────────────────────────────────
const prendreCommande = async (req, res, next) => {
  const { id }      = req.params;
  const livreurId   = req.user.id;
  const client      = await pool.connect();

  try {
    await client.query('BEGIN');

    // Verrouiller la ligne pour éviter les prises simultanées
    const result = await client.query(
      `SELECT statut FROM commandes WHERE id = $1 FOR UPDATE`,
      [id]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ success: false, message: 'Commande introuvable.' });
    }

    if (result.rows[0].statut !== 'nouvelle') {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Cette commande a déjà été prise en charge.',
      });
    }

    // Mettre à jour la commande
    await client.query(
      `UPDATE commandes
       SET statut = 'prise', livreur_id = $1, maj_le = NOW()
       WHERE id = $2`,
      [livreurId, id]
    );

    // Enregistrer dans l'historique
    await client.query(
      `INSERT INTO historique_statuts (commande_id, statut, modifie_par, notes)
       VALUES ($1, 'prise', $2, 'Commande prise en charge par le livreur')`,
      [id, livreurId]
    );

    await client.query('COMMIT');

    res.status(200).json({
      success: true,
      message: 'Commande prise en charge avec succès.',
    });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

// ─────────────────────────────────────────────
// PUT /api/livreur/commandes/:id/statut
// Le livreur change le statut d'une commande
// ─────────────────────────────────────────────
const changerStatut = async (req, res, next) => {
  const { id }      = req.params;
  const { statut }  = req.body;
  const livreurId   = req.user.id;

  if (!STATUTS_VALIDES.includes(statut)) {
    return res.status(400).json({ success: false, message: 'Statut invalide.' });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const result = await client.query(
      `SELECT statut, livreur_id FROM commandes WHERE id = $1 FOR UPDATE`,
      [id]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ success: false, message: 'Commande introuvable.' });
    }

    const commande = result.rows[0];

    // Vérifier que c'est bien la commande de ce livreur
    if (commande.livreur_id !== livreurId) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Vous n\'êtes pas assigné à cette commande.',
      });
    }

    // Vérifier la transition de statut
    const transitionsAutorisees = TRANSITIONS[commande.statut] || [];
    if (!transitionsAutorisees.includes(statut)) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: `Transition invalide : ${commande.statut} → ${statut}`,
      });
    }

    await client.query(
      `UPDATE commandes SET statut = $1, maj_le = NOW() WHERE id = $2`,
      [statut, id]
    );

    await client.query(
      `INSERT INTO historique_statuts (commande_id, statut, modifie_par)
       VALUES ($1, $2, $3)`,
      [id, statut, livreurId]
    );

    await client.query('COMMIT');

    res.status(200).json({ success: true, message: `Statut mis à jour : ${statut}` });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
};

module.exports = { getCommandesDisponibles, prendreCommande, changerStatut };
