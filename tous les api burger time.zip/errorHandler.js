// src/middlewares/errorHandler.js

/**
 * Middleware global de gestion des erreurs.
 * À placer en dernier dans app.js (après toutes les routes).
 */
const errorHandler = (err, req, res, next) => {
  console.error(`[ERREUR] ${err.message}`);

  const statusCode = err.statusCode || 500;

  res.status(statusCode).json({
    success: false,
    message: err.message || 'Erreur interne du serveur.',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

module.exports = errorHandler;
