// src/controllers/authController.js
const bcrypt        = require('bcrypt');
const pool          = require('../config/db');
const generateToken = require('../utils/generateToken');

/**
 * POST /api/auth/connexion
 * Authentifie un livreur ou un administrateur et retourne un token JWT.
 */
const connexion = async (req, res, next) => {
  const { email, mot_de_passe } = req.body;

  try {
    // 1. Récupérer l'utilisateur actif par email
    const result = await pool.query(
      `SELECT * FROM utilisateurs WHERE email = $1 AND actif = true`,
      [email]
    );

    const user = result.rows[0];

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Identifiants incorrects.',
      });
    }

    // 2. Vérifier le mot de passe
    const motDePasseValide = await bcrypt.compare(mot_de_passe, user.mot_de_passe_hash);

    if (!motDePasseValide) {
      return res.status(401).json({
        success: false,
        message: 'Identifiants incorrects.',
      });
    }

    // 3. Mettre à jour la date de dernière connexion
    await pool.query(
      `UPDATE utilisateurs SET derniere_connexion = NOW() WHERE id = $1`,
      [user.id]
    );

    // 4. Générer et retourner le token JWT
    const token = generateToken(user);

    return res.status(200).json({
      success: true,
      message: 'Connexion réussie.',
      token,
      user: {
        id:         user.id,
        nom_complet: user.nom_complet,
        email:      user.email,
        role:       user.role,
      },
    });

  } catch (err) {
    next(err);
  }
};

module.exports = { connexion };
