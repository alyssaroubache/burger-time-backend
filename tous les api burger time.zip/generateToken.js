// src/utils/generateToken.js
const jwt = require('jsonwebtoken');

/**
 * Génère un token JWT pour un utilisateur authentifié.
 * @param {Object} user - L'utilisateur (doit avoir id et role)
 * @returns {string} Token JWT signé, valide 8 heures
 */
const generateToken = (user) => {
  return jwt.sign(
    {
      id:   user.id,
      role: user.role,
    },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );
};

module.exports = generateToken;
