// src/middlewares/auth.js
const jwt = require('jsonwebtoken');

/**
 * Middleware de protection : vérifie la présence et la validité du token JWT.
 * À utiliser sur toutes les routes privées.
 */
const protect = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Accès refusé. Token manquant ou mal formaté.',
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { id, role }
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Token invalide ou expiré.',
    });
  }
};

/**
 * Middleware de rôle : autorise uniquement les administrateurs.
 * À utiliser après `protect`.
 */
const isAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Accès réservé aux administrateurs.',
    });
  }
  next();
};

/**
 * Middleware de rôle : autorise uniquement les livreurs.
 * À utiliser après `protect`.
 */
const isLivreur = (req, res, next) => {
  if (req.user?.role !== 'livreur') {
    return res.status(403).json({
      success: false,
      message: 'Accès réservé aux livreurs.',
    });
  }
  next();
};

module.exports = { protect, isAdmin, isLivreur };
