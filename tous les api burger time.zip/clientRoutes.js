// src/routes/clientRoutes.js
const express    = require('express');
const router     = express.Router();
const {
  getCategories,
  getProduits,
  getProduitById,
  createCommande,
  getCommandeById,
} = require('../controllers/clientController');
const { requireFields } = require('../middlewares/validation');

/**
 * GET /api/categories
 * Liste de toutes les catégories actives
 */
router.get('/categories', getCategories);

/**
 * GET /api/produits
 * Liste des produits disponibles (filtrable par ?categorieId=X)
 */
router.get('/produits', getProduits);

/**
 * GET /api/produits/:id
 * Détail d'un produit spécifique
 */
router.get('/produits/:id', getProduitById);

/**
 * POST /api/commandes
 * Créer une nouvelle commande
 */
router.post(
  '/commandes',
  requireFields([
    'client_prenom',
    'client_nom',
    'client_telephone',
    'adresse_livraison',
    'heure_prevue',
    'produits',
  ]),
  createCommande
);

/**
 * GET /api/commandes/:id
 * Récupérer le détail d'une commande (pour suivi client)
 */
router.get('/commandes/:id', getCommandeById);

module.exports = router;
