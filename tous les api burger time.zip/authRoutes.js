// src/routes/authRoutes.js
const express        = require('express');
const router         = express.Router();
const { connexion }  = require('../controllers/authController');
const { requireFields } = require('../middlewares/validation');

/**
 * POST /api/auth/connexion
 * Connexion d'un livreur ou d'un administrateur
 */
router.post(
  '/connexion',
  requireFields(['email', 'mot_de_passe']),
  connexion
);

module.exports = router;
